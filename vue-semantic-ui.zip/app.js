var study = new Vue({
  el: "#vue-app",
  data: {
    heading: "Vue.js + Semantic UI",
    text: "Experience is something you get just after you need it."
  }
});
