angular.module("app", [])
  .controller("MainCtrl", function ($scope) {
    $scope.heading = "AngularJS + Bootstrap";
    $scope.text = "Where in the nursery rhyme does it say Humpty Dumpty is an egg?";
  });
