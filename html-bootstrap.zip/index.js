angular.module("app", [])
  .controller("MainCtrl", function ($scope) {
    $scope.heading = "AngularJS + Bootstrap";
    $scope.text = "Rome wasn't built in a day, it just looks like that.";
  });
