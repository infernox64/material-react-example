var study = new Vue({
  el: "#vue-app",
  data: {
    heading: "Vue.js + Bulma",
    text: "A dog is a dog unless he is facing you. Then he is Mr. Dog."
  }
});
