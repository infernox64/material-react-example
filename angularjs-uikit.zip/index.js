angular.module("app", [])
  .controller("MainCtrl", function ($scope) {
    $scope.heading = "AngularJS + UIkit";
    $scope.text = "Don't personify computers - we don't like it.";
  });
