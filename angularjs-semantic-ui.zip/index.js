angular.module("app", [])
  .controller("MainCtrl", function ($scope) {
    $scope.heading = "AngularJS + Semantic UI";
    $scope.text = "The trouble with doing something right the first time, is nobody appreciates how difficult it was.";
  });
