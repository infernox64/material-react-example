angular.module("app", [])
  .controller("MainCtrl", function ($scope) {
    $scope.heading = "AngularJS + Material Design Lite";
    $scope.text = "Personifiers of the world! Unite! You have nothing to lose but Mr. Dignity!";
  });
