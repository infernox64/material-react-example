angular.module("app", [])
  .controller("MainCtrl", function ($scope) {
    $scope.heading = "AngularJS + Bulma";
    $scope.text = "Experience is something you get just after you need it.";
  });
