var study = new Vue({
  el: "#vue-app",
  data: {
    heading: "Vue.js + Material Design Lite",
    text: "Give a man a fish and you feed him for a day. Teach a man to fish, and you can sell him some tackle."
  }
});
