var study = new Vue({
  el: "#vue-app",
  data: {
    heading: "Vue.js + UIkit",
    text: "Hard work pays off in the future. Laziness pays off now."
  }
});
