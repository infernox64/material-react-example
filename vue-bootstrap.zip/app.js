var study = new Vue({
  el: "#vue-app",
  data: {
    heading: "Vue.js + Bootstrap",
    text: "A neat desk is a sign of a cluttered desk drawer."
  }
});
